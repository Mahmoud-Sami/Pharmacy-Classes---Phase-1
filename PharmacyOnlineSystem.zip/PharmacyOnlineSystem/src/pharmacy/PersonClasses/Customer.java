package pharmacy.PersonClasses;
import pharmacy.ExtraClasses.DateTime;
public class Customer extends Person {

    private String shippingAddress;
    public Customer(String username, String password, String firstName, String lastName, String phone, String gender, DateTime dateOfBirth, String shippingAddress) {
        super(username, password, firstName, lastName, phone, gender, dateOfBirth);
        this.shippingAddress = shippingAddress;
    }

    public String getShippingAddress() {
        return shippingAddress;
    }

    public void setShippingAddress(String shippingAddress) {
        this.shippingAddress = shippingAddress;
    }

    @Override
    public String toString() {
        return "Customer{" + "shippingAddress=" + shippingAddress + '}';
    }
    
    
}