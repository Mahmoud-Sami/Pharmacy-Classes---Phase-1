/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pharmacy.PersonClasses;
import pharmacy.ExtraClasses.DateTime;
import pharmacy.MainClasses.PharmacyController.OrderTable;
import pharmacy.ProductClasses.*;
public class AdminReport extends Staff{

    public AdminReport(String username, String password, String firstName, String lastName, String phone, String gender, DateTime dateOfBirth) {
        super(username, password, firstName, lastName, phone, gender, dateOfBirth);
    }

    
    
}
