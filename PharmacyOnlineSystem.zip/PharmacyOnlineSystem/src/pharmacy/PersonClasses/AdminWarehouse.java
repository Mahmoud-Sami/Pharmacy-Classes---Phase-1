package pharmacy.PersonClasses;

import pharmacy.ExtraClasses.DateTime;
import pharmacy.MainClasses.PharmacyController.ProductTable;
public class AdminWarehouse extends Staff {

    public AdminWarehouse(String username, String password, String firstName, String lastName, String phone, String gender, DateTime dateOfBirth) {
        super(username, password, firstName, lastName, phone, gender, dateOfBirth);
    }

    public void BringMissingProducts(){
        for (int i = 0; i < ProductTable.getProducts_Number(); i++){
            if (ProductTable.getProductOfIndex(i).getQuantity() < 10){
                ProductTable.getProductOfIndex(i).AddQuantity(10);
            }
        }
    }
}
