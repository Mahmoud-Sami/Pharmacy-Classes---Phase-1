package pharmacy.ExceptionClasses;

public class InvalidInputException extends Exception {

    public InvalidInputException(String string) {
        super(string);
    }
    
}
