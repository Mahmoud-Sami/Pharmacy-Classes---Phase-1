
package pharmacy.ExceptionClasses;


public class QuantityLimitException extends Exception {

    public QuantityLimitException(String string) {
        super(string);
    }
    
}
